#!/bin/sh
#
# At first, check terminal whether MuTerminal.
# If terminal isn't MuTerminal, "mt_set -v" returns an exit status of 1.
mt_set -v && {
    #
    # save now encoding
    #
    NOW_CODE=`mt_set -c`
    #
    # set encoding
    #
    mt_set -s SJIS
    export TTYPE=SJIS
    echo set coding is [$NOW_CODE]

    # following command bind set encoding
    # ex.)
    # telnet r2.niftyserve.or.jp ( remote host encoding is SJIS)
    #
    # restore encoding
    #
    export TTYPE=$NOW_CODE
    mt_set -s $NOW_CODE
    echo restore coding is [$TTYPE]
}

#end of script
