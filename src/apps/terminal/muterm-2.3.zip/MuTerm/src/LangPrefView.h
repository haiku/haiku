/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 LangPrefView.h,v 2.5 1999/10/02 15:15:03 kaz Exp
 LangPrefView.h,v: Interface for MuTerminal Language Preference View.

***************************************************************************/

#ifndef LangPrefView__H_INCLUDED
#define LangPrefView__H_INCLUDED

#include "PrefView.h"

class TermWindow;

class LangPrefView : public PrefView
{
 public:
                LangPrefView (BRect r, const char *name, TermWindow *window);

  void          Revert (void);
  void          SetControlLabels (PrefHandler &Labels);

  void          AttachedToWindow (void);
  void          MessageReceived (BMessage *);
  
 private:
  BMenuField    *mCharCode;
  BMenuField	*mLanguage;
  BCheckBox	*mInputMethod;

  TermWindow 	*fTermWindow;
  
};

#endif //ShellPrefView_H_INCLUDED
