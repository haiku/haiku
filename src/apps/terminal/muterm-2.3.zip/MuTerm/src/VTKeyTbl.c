/*  Hey Emacs, this file is -*- c++ -*- ; 

	Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 VTKeyTbl.c,v 2.0 1999/10/02 15:08:58 kaz Exp
 VTKeyTbl.c,v: keymap Table.

*****************************************************************************/

#include "VTkeymap.h"

int function_keycode_table[] =
{
F1_KEY,
F2_KEY,
F3_KEY,
F4_KEY,
F5_KEY,
F6_KEY,
F7_KEY,
F8_KEY,
F9_KEY,
F10_KEY,
F11_KEY,
F12_KEY,
};

char *function_key_char_table [] = 
{
"[11~",
"[12~",
"[13~",
"[14~",
"[15~",
"[16~",
"[17~",
"[18~",
"[19~",
"[20~",
"[21~",
"[22~",
};
