/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 TermBaseView.cpp,v 2.4 1999/10/13 15:20:09 kaz Exp
 TermBaseView.cpp,v: Implementation for BView sub class.

***************************************************************************/

#include "TermBaseView.h"
#include "TermView.h"

/************************************************************************
 *
 * CONSTRUCTOR and DESTRUCTOR
 *
 ***********************************************************************/

////////////////////////////////////////////////////////////////////////////
// TermBaseView ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
TermBaseView::TermBaseView (BRect frame, TermView *inTermView)
  :BView (frame, "baseview", B_FOLLOW_ALL_SIDES,
	  B_WILL_DRAW | B_FRAME_EVENTS)
{

  fTermView = inTermView;

}

////////////////////////////////////////////////////////////////////////////
// ~TermBaseView ()
//	Destructor.
////////////////////////////////////////////////////////////////////////////
TermBaseView::~TermBaseView ()
{
}

/*
 * PUBLIC MEMBER FUNCTIONS.
 */

////////////////////////////////////////////////////////////////////////////
// FrameResized (float, float)
//	Dispatch frame resize event.
////////////////////////////////////////////////////////////////////////////
void
TermBaseView::FrameResized (float width, float height)
{
  int font_width, font_height;
  int cols, rows;

  fTermView->GetFontInfo (&font_width, &font_height);

  cols = (int)(width - VIEW_OFFSET * 2) / font_width;
  rows = (int)(height - VIEW_OFFSET * 2)/ font_height;

  fTermView->ResizeTo (cols * font_width - 1, rows * font_height - 1);
  
}
