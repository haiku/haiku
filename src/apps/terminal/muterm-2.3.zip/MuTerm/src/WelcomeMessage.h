/* Hey Emacs, this file is -*- c++ -*- -*- coding:utf-8-unix -*-

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 WelcomeMessage.h,v 2.3 1999/10/02 15:26:49 kaz Exp
 WelcomeMessage.h,v: define Welcome message.
 
***************************************************************************/
#ifndef WELCOMEMESSAGE_H_INCLUDED
#define WELCOMEMESSAGE_H_INCLUDED

#define MUTERM_MESSAGE "[4;34mM[31mu[mTerm"

#define LANG_MAX 16
#define TIME_MES_MAX 3

const char *welcome_message[] = {
  "\n%s, Welcome to %s World!\n", 	/* English */
  "\n%s、ようこそ%sへ！\n",		/* Japanese */
  "\n%s, Dobro došli %s!\n",		/* Croatian */
  "\n%s, Vítá vás %s!\n",		/* Czech */
  "\n%s, Velkommen til %s!\n",		/* Danish */
  "\n%s, Wilkom bij %s!\n",		/* Dutch */
  "\n%s, Tervetuloa %s!\n",		/* Finnish */
  "\n%s, Bienvenue en %s!\n",		/* French */
  "\n%s, Willkommen zu %s!\n",		/* German */
  "\n%s, Isten hozott a %s!\n",		/* Hungarian */
  "\n%s, %s heilsar!\n",		/* Islandish */
  "\n%s, Benvenuto in %s!\n",		/* Italian */
  "\n%s, Velkommen til %s!\n",		/* Norwegian */
  "\n%s, Bem-vindo ao %s!\n",		/* Portuguese */
  "\n%s, ¡Bienvenido a %s!\n",		/* Spanish */
  "\n%s, Välkommen til %s!\n",		/* Swedish */
 
};

const char *hello_message[LANG_MAX][TIME_MES_MAX] = {
  {"Good Morning", "Hello", "Good Evening"}, 		/* English */
  {"おはよう", "こんにちは", "こんばんは"},		/* Japanese */
  {"Dobro jutro", "Dobro dan", "Dobro večer"},		/* Croatian */
  {"Dobré ráno", "Dobrý den", "Dobrý večer"},		/* Czecho */
  {"God morgen", "God dag", "God aftn"},		/* Danish */
  {"Goede morgen", "Goede middag", "Goede avond"}, 	/* Dutch */
  {"Hyvää huomenta", "Hyvää päivää", "Hyvää iltaa"}, 	/* Finnish */
  {"Bonjour", "Bonjour", "Bon soir"},			/* French */
  {"Guten Morgen", "Guten Tag", "Guten Abend"},		/* German */
  {"Jó reggelt kívánok", "Jó napot kívánok", "Jó estét kívánok"}, /* Hungarian */
  {"Góđan daginn", "Góđan daginn", "Gótt kvöld"}, 	/* Islandish */
  {"Buon giorno", "Buon giorno", "Buona sera"}, 	/* Italian */
  {"God morge", "God dag", "God kveld"},	 	/* Norwegian */
  {"Bom dia", "Boa tarde", "Boa noite"},	 	/* Portuguese */
  {"Buenos días", "Buenos tardes", "Buenos noches"}, 	/* Spanish */
  {"God morgon", "God dag", "God kväll"},	 	/* Swedish */
  

  

};


#endif /* TERMCONST_H_INCLUDED */

