/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 mt_set.cpp,v 2.0 1999/10/02 15:08:59 kaz Exp
 mt_set.cpp,v: Implementation for MuTerminal coding utility.

***************************************************************************/

/*
 *  Revision and Version infomation.
 */
char *rcs_rev = "2.0";
char *mt_ver = "1.2 (KOKUU)";
char *last_update = "1999/10/02 15:08:59";
#ifdef __INTEL__
char *machine_type = "for x86";
#else
char *machine_type = "for PPC";
#endif

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <Application.h>
#include <InterfaceKit.h>

#include "muterm.h"


static void show_terminfo();
static void show_langinfo();
static void set_langinfo(const char *lang);
static void reset_terminfo(void);
static void show_usage (void);
static int check_arg (int argc, char **argv);
static int32 shortname2op(const char *shortname);

#define PTYCHAR1	"pqrs"
#define	PTYCHAR2	"0123456789abcdef"

////////////////////////////////////////////////////////////////////////////
// main (int argc, char **argv)
// main routine of MuTerminal.
////////////////////////////////////////////////////////////////////////////
int
main (int argc, char **argv)
{
  BApplication app();

  /* terminal option '--help' view help screen */

  return check_arg (argc, argv);

}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
int
check_arg(int argc, char **argv)
{
  //char *dev_name;
  int err_no, c;
  int32 coding;
  const etable *p = encoding_table;

  if (argc < 2 || argc > 3) goto error;
  if (*argv[1] != '-') goto error;
  
  switch(*(argv[1] + 1)){
  case 'a':
    show_terminfo();
    break;

  case 'c':
    c = get_coding();
    if (c == -1) {
      printf ("mt_set::Can't get coding information from this terminal.\n");
      return -1;
    } else {
      p += c;
      printf ("%s\n", p->shortname);
    }
    break;

  case 'l':
    show_langinfo();
    break;

  case 's':
    coding = shortname2op(argv[2]);
    err_no = set_coding(coding);
    if (err_no == -1) {
      printf ("mt_set::Not supports '%s' encoding.\n",argv[2]);
      return -1;
    }
    else if (err_no == 1) {
      printf ("mt_set::This terminal couldn't change character code.\n");
      //printf ("(%s)\n", dev_name);
      return -1;
    }else{
      if(strlen(argv[1]) != 2) goto error;
      set_langinfo(argv[2]);
    }
    break;

  case 'r':
    reset_terminfo();
    break;

  case 'h':
    show_usage ();
    break;
    
  case 'v':
    if (check_muterm() == -1) {
      printf ("This Terminal is not MuTerminal.\n");
      return -1;
    }
    break;

  default:
    goto error;
    break;
  }
  return 0;

 error:  
  printf ("invalid option.\n");
  printf ("Try %s -h for more information.\n", argv[0]);
  return -1;
}

////////////////////////////////////////////////////////////////////////////
// show_usage (void)
// Print usage.
////////////////////////////////////////////////////////////////////////////
void
show_usage (void)
{
  printf ("\n");
  printf ("MuTerminal coding utility [31m\"mt_set\"[m version %s\n", mt_ver);
  printf ("Usage: mt_set [-c] [-h] [-s encoding] [-v] \n");
  printf ("\t-c  Print Muterminal current encoding. \n");
  printf ("\t-s  Set Muterminal encoding. \n");
  printf ("\t-h  Show help. \n");
  printf ("\t-v  Check this terminal whether MuTerminal. \n");
  printf ("avalable encodings are\n");
  
  const etable *p = encoding_table;
  while(p->name){
      printf ("\t-s %s Set Encoding to %s.\n", p->shortname, p->name);
      p++;
  }
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
show_terminfo()
{
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
show_langinfo()
{
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
set_langinfo(const char *lang)
{
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
reset_terminfo(void)
{
}

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
int32
shortname2op(const char *shortname)
{
  int32 ret = 0;
  const etable *p = encoding_table;
  while(p->name){
      if(!strcmp(p->shortname, shortname)){
        ret = p->op;
        break;
      }
      p++;
  }

  return ret;
}

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
