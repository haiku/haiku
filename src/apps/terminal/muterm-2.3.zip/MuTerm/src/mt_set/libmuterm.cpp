/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 libmuterm.cpp,v 2.2 2000/04/01 17:13:29 kaz Exp
 libmuterm.cpp,v: Implementation for MuTerminal library.

***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <InterfaceKit.h>
#include <Roster.h>
#include <app/Application.h>
#if B_BEOS_VERSION >= 0x0450
#include <bsd_mem.h>
#endif

#include "muterm.h"

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
int
get_coding()
{
  BList tmpList;
  int32 i, n, coding = 0;
  team_id theTeam;
  char *send_dev;
  const char *recv_dev;

  send_dev = getenv("TTY");
  send_dev += 8;

  be_roster->GetAppList(MUTERM_SIGNATURE, &tmpList);

  n = tmpList.CountItems ();
  
  for (i = 0; i < n; ++i){
    theTeam = (team_id) tmpList.ItemAt(i);

	BMessage message, reply; 
	BMessenger mt(MUTERM_SIGNATURE, theTeam);
	/*
	 * Get MuTerminal tty
	 */
	message.what = B_GET_PROPERTY; 
	message.AddSpecifier("tty"); 
	message.AddSpecifier("Window", (int32)0); 

	mt.SendMessage(&message, &reply); 

	recv_dev = reply.FindString ("result");

	if (bcmp (recv_dev, send_dev, 2) == 0) {
	  /*
	   * Get coding from window .
	   */
       message.MakeEmpty();
       message.what = B_GET_PROPERTY; 
       message.AddSpecifier("encode"); 
       message.AddSpecifier("Window", (int32)0); 
       mt.SendMessage(&message, &reply); 
       uint32 op = reply.FindInt32 ("result");

       const etable *p = encoding_table;
       while(p->name){
	    if ( p->op == op) {
	      return coding;
	    }
	    p++;
	    coding++;
	  }
	}
  }
  return -1;
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
int  
set_coding (int32 coding)
{
  BList tmpList;
  int i, n;
  char *send_dev;
  const char *recv_dev;
  team_id theTeam;

  send_dev = getenv("TTY");
  send_dev += 8;

  be_roster->GetAppList(MUTERM_SIGNATURE, &tmpList);

  n = tmpList.CountItems ();
  
  for (i = 0; i < n; ++i){
    theTeam = (team_id) tmpList.ItemAt(i);
	/*
	 * Find App is MuTerminal.
	 */

	BMessage message, reply; 
	BMessenger mt(MUTERM_SIGNATURE, theTeam);
	/*
	 * Get MuTerminal Window Title string
	 */
	message.what = B_GET_PROPERTY; 
	message.AddSpecifier("tty"); 
	message.AddSpecifier("Window", (int32)0); 
	// find window and get window title
	BMessenger aWin; 
	mt.SendMessage(&message, &reply); 
	
	recv_dev = reply.FindString ("result");

	if (bcmp (recv_dev, send_dev, 2) == 0) {
	  /*
	   * Get first window specify
	   */
	  message.MakeEmpty();
	  message.what = B_SET_PROPERTY;
	  message.AddInt32("data", coding);
	  message.AddSpecifier("encode"); 
	  message.AddSpecifier ("Window", (int32) 0);
	  mt.SendMessage (&message, &reply);
	  return 0;
	}
  }
  return 1;
}

////////////////////////////////////////////////////////////////////////////
// check_muterm ()
//	Check terminal whether MuTerminal.
////////////////////////////////////////////////////////////////////////////
int
check_muterm (void)
{
  BList tmpList;
  int32 i, n;
  team_id theTeam;
  char *send_dev;
  const char *recv_dev;

  send_dev = getenv("TTY");
  send_dev += 8;

  be_roster->GetAppList(MUTERM_SIGNATURE, &tmpList);

  n = tmpList.CountItems ();
  
  for (i = 0; i < n; ++i){
    theTeam = (team_id) tmpList.ItemAt(i);

	BMessage message, reply; 
	BMessenger mt(MUTERM_SIGNATURE, theTeam);
	/*
	 * Get MuTerminal tty
	 */
	message.what = B_GET_PROPERTY; 
	message.AddSpecifier("tty"); 
	message.AddSpecifier("Window", (int32)0); 

	mt.SendMessage(&message, &reply); 

	recv_dev = reply.FindString ("result");

	if (bcmp (recv_dev, send_dev, 2) == 0)
	  return 0;
  }
  return -1;
}

