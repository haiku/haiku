/***************************************************************************
 Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 muterm.h,v 2.1 1999/12/05 01:47:07 kaz Exp
 muterm.h,v: muterm library header.

***************************************************************************/
#ifndef MUTERMLIB_H
#define MUTERMLIB_H

#define MUTERM_SIGNATURE "application/x-vnd.naan-mterm"

#include "Coding.h"

int get_coding (void);
int set_coding (int32 coding);
int check_muterm();

#endif //MUTERMLIB_H
