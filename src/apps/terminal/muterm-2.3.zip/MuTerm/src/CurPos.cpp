/* Hey Emacs, this file is -*- c++ -*-

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 CurPos.cpp,v 2.3 1999/10/17 04:43:15 kaz Exp
 CurPos.cpp,v: Implimentation for CurPos class.

***************************************************************************/

#include "CurPos.h"



/*************************************************************************
 *
 * Constructor and Destructor
 *
 ************************************************************************/

CurPos::CurPos()
{
}


CurPos::CurPos(int32 X, int32 Y)
{
  x = X;
  y = Y;
}


CurPos::CurPos(const CurPos& cp)
{
  x = cp.x;
  y = cp.y;
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator =
////////////////////////////////////////////////////////////////////////////
CurPos &
CurPos::operator=(const CurPos& from)
{
  x = from.x;
  y = from.y;
  return *this;
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Set Function.
////////////////////////////////////////////////////////////////////////////
void
CurPos::Set(int32 X, int32 Y)
{
  x = X;
  y = Y;
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator !=
////////////////////////////////////////////////////////////////////////////
bool
CurPos::operator!=(const CurPos& from) const
{
  return ((x != from.x) || (y != from.y));
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator ==
////////////////////////////////////////////////////////////////////////////
bool
CurPos::operator==(const CurPos& from) const
{
  return ((x == from.x) && (y == from.y));
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator +
////////////////////////////////////////////////////////////////////////////
CurPos
CurPos::operator+(const CurPos& from) const
{
  return CurPos(x + from.x, y + from.y);
}
////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator -
////////////////////////////////////////////////////////////////////////////
CurPos
CurPos::operator- (const CurPos& from) const
{
  return CurPos(x - from.x, y - from.y);
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator >
////////////////////////////////////////////////////////////////////////////
bool
CurPos::operator> (const CurPos& from) const
{
  if (y > from.y) {
    return true;
  } else if (y == from.y && x > from.x) {
    return true;
  }
  
  return false;
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator >=
////////////////////////////////////////////////////////////////////////////
bool
CurPos::operator>= (const CurPos& from) const
{
  if (y > from.y) {
    return true;
  } else if (y == from.y && x >= from.x) {
    return true;
  }
  
  return false;
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator <
////////////////////////////////////////////////////////////////////////////
bool
CurPos::operator< (const CurPos& from) const
{
  if (y < from.y) {
    return true;
  } else if (y == from.y && x < from.x) {
    return true;
  }
  
  return false;
}

////////////////////////////////////////////////////////////////////////////
// CurPos
//	Operator <=
////////////////////////////////////////////////////////////////////////////
bool
CurPos::operator<= (const CurPos& from) const
{
  if (y < from.y) {
    return true;
  } else if (y == from.y && x <= from.x) {
    return true;
  }
  
  return false;
}
