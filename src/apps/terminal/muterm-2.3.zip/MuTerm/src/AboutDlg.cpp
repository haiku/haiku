/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 AboutDlg.cpp,v 1.5 2000/04/01 17:13:29 kaz Exp
 AboutDlg.cpp,v Implementation for MuTerminal About Dialog.

***************************************************************************/
#include <Rect.h>
#include <View.h>
#include <TextView.h>
#include <TranslatorRoster.h>
#include <BitmapStream.h>
#include <Bitmap.h>
#include <Message.h>
#include <Screen.h>
#include <stdio.h>
#include <File.h>
#include <String.h>

#include "AboutDlg.h"
#include "TermApp.h"
#include "PrefHandler.h"
#include "MenuUtil.h"

const char *title_font_name = "Swiss911 XCm BT";

extern char *rcs_rev;
extern char *muterm_ver;
extern char *last_update;
extern char *machine_type;

//////////////////////////////////////////////////////////////////////////////
// AboutDlg
// 	Constructer
//////////////////////////////////////////////////////////////////////////////
AboutDlg::AboutDlg (BRect frame, TermApp *app)
  : BWindow(frame, "About MuTerminal",
	    B_TITLED_WINDOW_LOOK, B_FLOATING_APP_WINDOW_FEEL,
	    B_NOT_RESIZABLE|B_NOT_ZOOMABLE)
{
  fApp = app;
  AboutView *view = new AboutView (Bounds ());
  AddChild (view);
  SetPulseRate (100 * 1000);

  PrefHandler text;
  LoadLocaleFile (&text);

  this->SetTitle (text.getString ("About MuTerminal"));
  
  this->Show();

}

AboutDlg::~AboutDlg (void)
{
  
}

void
AboutDlg::Quit (void)
{
  fApp->PostMessage (MSG_ABOUT_CLOSED);
  BWindow::Quit ();
}

/*
 * About panel view object
 */
AboutView::AboutView (BRect frame)
  :BView (frame, NULL, B_FOLLOW_NONE, B_WILL_DRAW | B_PULSE_NEEDED)
{
  staffroll = false;
  count = 10;
  offscreen = NULL;
  textbitmap = NULL;
  
}

AboutView::~AboutView ()
{
  if (background)
    delete background;
  if (textbitmap)
    delete textbitmap;
  if (offscreen)
    delete offscreen;
  
}

#define BACKIMAGE "/boot/home/config/settings/MuTerminal/help/pics/muterm.jpg"
#define LOGOIMAGE "/boot/home/config/settings/MuTerminal/help/pics/logo.jpg"

void
AboutView::AttachedToWindow (void)
{
  /* Create background bitmap. */
  BFile file (BACKIMAGE, B_READ_ONLY);
  if (file.InitCheck () == B_NO_ERROR) {
    BTranslatorRoster *roster = BTranslatorRoster::Default ();
    BBitmapStream stream;
    roster->Translate (&file, NULL, NULL, &stream, B_TRANSLATOR_BITMAP);
    stream.DetachBitmap (&background);
  }
  else {
    background = new BBitmap (Bounds (), B_COLOR_8_BIT, false);
  }
  

  BRect rect(0, 0, 350, 1000);

  /* Create offscreen bitmap. */
  BView *view = new BView (Bounds(), NULL, B_FOLLOW_NONE, 0);
  offscreen = new BBitmap (Bounds(), B_RGB32, true);
  offscreen->AddChild (view);

  /* Create text bitmap. */
  textbitmap = new BBitmap (rect, B_RGB32, true);
  BTextView *offview = new BTextView (rect, NULL, rect,
				      B_FOLLOW_NONE, 0);
  textbitmap->AddChild (offview);
  
  textbitmap->Lock ();

  BFont *font = new BFont ();
  font->SetFamilyAndStyle ("Humnst777 BT", "Bold");
  font->SetSize (11);
  offview->SetFont (font);
  delete font;
  
  // Fill background transparent
  offview->SetHighColor (255,255,255,0); //alpha = 0 (trabnsparent)
  offview->FillRect (offview->Bounds());
  offview->SetHighColor (255,255,255,255);

  BString aboutMsg;
  aboutMsg
    << "\n"
    << "\"MuTerminal\" version "
    << muterm_ver << " " << machine_type <<"\n"
    << "(Revision:" << rcs_rev
    << " LastUpdate:" << last_update  <<")\n"
    << "Copyrigth " B_UTF8_COPYRIGHT "1999, 2000 Kazuho Okui and Takashi Murai.\n"
    "ALL RIGHT RESERVED.\n"
    "\n"
    "You may redistribute copies of MuTerminal\n"
    "under the terms of the GNU General Public License.\n"
    "For more information about Help menu.\n\n\n\n\n"
    "Staff of MuTerimnal development\n\n\n"
    "Directing and coding:\n"
    "\tKazuho Okui\n\n"
    "Coding:\n"
    "\tTakashi Murai\n\n"
    "Examination and documentation\n"
    "for multilingualization:\n"
    "\tSatoshi Otsuka\n\n"
    "Documentation:\n"
    "\tKenichi Nagaoka\n\n"
    "Beta tester:\n"
    "\tGoro Kiyono\n"
    "\tHideki Naito\n"
    "\tHirotaka Ichikawa\n"
    "\tJun Okada\n"
    "\tMasaaki Hirai\n"
    "\tMasashi Sawada\n"
    "\tMasayuki Ookubo\n"
    "\tMasayuki Yashiro\n"
    "\tShigeru Kobayashi\n"
    "\tTakayuki Ito\n"
    "\tRyo Taya\n"
    "\tShuichi Nakamura\n\n"
    "Special Thanks:\n"
    "\tToshihiro Kisaka\n\n"
    "\tAnd all MuTerm users!";

  offview->SetText (aboutMsg.String());
  BPoint logo_p = offview->PointAt (offview->OffsetAt (offview->CountLines ()));
  last_point = (int32) logo_p.y + (int32) offview->LineHeight ();
  
  file.SetTo (LOGOIMAGE, B_READ_ONLY);
  if (file.InitCheck () == B_NO_ERROR) {
    BTranslatorRoster *roster = BTranslatorRoster::Default ();
    BBitmapStream stream;
    roster->Translate (&file, NULL, NULL, &stream, B_TRANSLATOR_BITMAP);
    BBitmap *logobitmap = NULL;
    stream.DetachBitmap (&logobitmap);
    offview->SetDrawingMode (B_OP_ALPHA);
    offview->SetHighColor (255, 255, 255);
    offview->SetBlendingMode (B_CONSTANT_ALPHA, B_ALPHA_OVERLAY);
    
    offview->DrawBitmap (logobitmap,
			 BPoint (10, logo_p.y + 51 + offview->LineHeight()));
  }
  

  /* Set transparent color to backgound. */
  int max = textbitmap->Bounds().IntegerWidth() *
    textbitmap->Bounds().IntegerHeight();
  uint32 *bits = (uint32 *)textbitmap->Bits();
  uint32 white = *bits;

  for (int i = 0; i < max; i++, bits++) {
    if (*bits == white) *bits = B_TRANSPARENT_MAGIC_RGBA32;
  }
  
  textbitmap->Unlock();
  
}

void
AboutView::MouseDown (BPoint where)
{
  if (staffroll == false) {
    staffroll = true;
  } else {
    staffroll = false;
    count = 10;
    Invalidate();
  }
  
}

void
AboutView::Pulse (void)
{
  if (staffroll && count > -last_point) {
    offscreen->Lock ();
    BView *view = offscreen->ChildAt (0);
    view->SetDrawingMode (B_OP_COPY);
    view->DrawBitmap (background);
    view->SetDrawingMode (B_OP_MIN);
    view->DrawBitmap (textbitmap, BPoint (10, count--));
    view->Sync();
  
    offscreen->Unlock ();
    DrawBitmap (offscreen);

    if (count < -last_point) {
      count = 10;
      //Invalidate ();
    }
  }
}

void
AboutView::Draw (BRect updateRect)
{
  offscreen->Lock ();
  BView *view = offscreen->ChildAt (0);

  view->SetDrawingMode (B_OP_COPY);
  view->DrawBitmap (background);
  view->SetDrawingMode (B_OP_MIN);
  view->DrawBitmap (textbitmap, BPoint (10, count));
  view->Sync();
  
  offscreen->Unlock ();
  DrawBitmap (offscreen, updateRect, updateRect);
}
