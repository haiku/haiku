/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 TTextControl.h,v 2.1 1999/10/02 15:18:21 kaz Exp
 TTextControl.h,v: Interface for BTextControl sub class.

***************************************************************************/

#ifndef TTEXTCTL_H_INCLUDED
#define TTEXTCTL_H_INCLUDED
#include <TextControl.h>

class TTextControl : public BTextControl
{
public:
  //
  // Constructor and Desctructor
  //
  TTextControl (BRect, const char *, const char *,
			      const char *, BMessage *);
  ~TTextControl ();

  //
  // public member functions.
  //
  void	ModifiedText (int);
  int	IsModified (void);

private:
  //
  // Data member.
  //
  int	mModified;
  
};

#endif /* TTEXT_CTL_H_INCLUDED */
