/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 MousePrefView.cpp,v 2.11 1999/10/17 04:43:15 kaz Exp
 MousePrefView.cpp,v: Implementation for MuTerminal Mouse Preference View.

***************************************************************************/

#include <View.h>
#include <Button.h>
#include <MenuField.h>
#include <Menu.h>
#include <MenuItem.h>
#include <PopUpMenu.h>
#include <TextControl.h>
#include <CheckBox.h>
#include <Directory.h>
#include <string.h>
#include <stdio.h>

#include "MousePrefView.h"
#include "PrefHandler.h"
#include "TermConst.h"
#include "TermWindow.h"
#include "MenuUtil.h"

////////////////////////////////////////////////////////////////////////////
// MousePrefView ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
MousePrefView::MousePrefView (BRect frame, const char *name, TermWindow *window)
  :PrefView (frame, name)
{
  const char *mousemenu[]={
     "Disable"
    ,"Button 1"
    ,"Button 2"
    ,"Button 3"
    , NULL
    };

  const char *mouseimage[]={
     "Hand cursor"
    ,"I Beam Cursor"
    , NULL
    };

  fTermWindow = window;
  
  //
  // Mouse.
  //
  mSelect = 
    SetupMenuField (IERECT (0, 0, 200, 20),
                    "",
                    MakeMenu(MSG_SELECT_CHANGED,
                    mousemenu,
                    gTermPref->getString(PREF_SELECT_MBUTTON)),
                    false);

  mSelect->SetDivider (120);

  mPaste =
    SetupMenuField (IERECT (0, 30, 200, 20),
                    "",
                    MakeMenu(MSG_PASTE_CHANGED,
                    mousemenu,
                    gTermPref->getString(PREF_PASTE_MBUTTON)),
                    false);


  mPaste->SetDivider (120);

  mSubMenu =
    SetupMenuField (IERECT (0, 60, 200, 20),
                   "",
                   MakeMenu(MSG_SUBMENU_CHANGED,
                   mousemenu,
                   gTermPref->getString(PREF_SUBMENU_MBUTTON)),
                   false);

  mSubMenu->SetDivider (120);

  //
  // Mouse Image
  //
  mMouseImage =
    SetupMenuField (IERECT (0, 90, 300, 20),
                   "",
                   MakeMenu(MSG_MIMAGE_CHANGED,
                   mouseimage,
                   gTermPref->getString(PREF_MOUSE_IMAGE)),
                   false);

  mMouseImage->SetDivider (120);

  mDragnCopy = SetupCheckBox(IERECT(0, 120, 200, 20),
			       "",
			       MSG_DRAGN_COPY_CHANGED);

  mDragnCopy->SetValue (gTermPref->getInt32 (PREF_DRAGN_COPY));
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
MousePrefView::Revert (void)
{
  mSelect->Menu()->
    FindItem (gTermPref->getString (PREF_SELECT_MBUTTON))->SetMarked(true);
  mSubMenu->Menu()->
    FindItem (gTermPref->getString(PREF_SUBMENU_MBUTTON))->SetMarked(true);
  mPaste->Menu()->
    FindItem (gTermPref->getString(PREF_PASTE_MBUTTON))->SetMarked(true);
  mMouseImage->Menu()->
    FindItem (gTermPref->getString(PREF_MOUSE_IMAGE))->SetMarked(true);
}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
MousePrefView::SetControlLabels (PrefHandler &Labels)
{
  mSelect->SetLabel(Labels.getString("Select Region"));
  mPaste->SetLabel(Labels.getString("Paste Label"));
  mSubMenu->SetLabel(Labels.getString("SubMenu Label"));
  mMouseImage->SetLabel(Labels.getString("Cursor Image"));
  mDragnCopy->SetLabel(Labels.getString("Drag'n Copy"));
}

/*
 *
 * PRIVATE MEMBER FUNCTIONS
 *
 */

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
MousePrefView::AttachedToWindow (void)
{
  mSelect->Menu()->SetTargetForItems(this);
  mSubMenu->Menu()->SetTargetForItems(this);  
  mPaste->Menu()->SetTargetForItems(this);
  mMouseImage->Menu()->SetTargetForItems(this);
  mDragnCopy->SetTarget (this);
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
MousePrefView::MessageReceived (BMessage *msg)
{
  bool modified = false;
  
  switch (msg->what) {

  case MSG_SELECT_CHANGED:
    gTermPref->setString (PREF_SELECT_MBUTTON,
			  mSelect->Menu()->FindMarked()->Label());
    modified = true;
    break;

  case MSG_SUBMENU_CHANGED:
    gTermPref->setString (PREF_SUBMENU_MBUTTON,
			  mSubMenu->Menu()->FindMarked()->Label());
    modified = true;
    break;

  case MSG_PASTE_CHANGED:
    gTermPref->setString (PREF_PASTE_MBUTTON,
			  mPaste->Menu()->FindMarked()->Label());
    modified = true;
    break;

  case MSG_MIMAGE_CHANGED:
    gTermPref->setString (PREF_MOUSE_IMAGE,
			  mMouseImage->Menu()->FindMarked()->Label());
    modified = true;
    break;

  case MSG_DRAGN_COPY_CHANGED:
    gTermPref->setInt32 (PREF_DRAGN_COPY, mDragnCopy->Value());
    break;

  default:
    PrefView::MessageReceived(msg);
    break;  

  }

  if(modified){
   fTermWindow->PostMessage (msg);
   (this->Window())->PostMessage(MSG_PREF_MODIFIED);
  }
}

