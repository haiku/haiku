/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 MenuUtil.h,v 2.4 1999/10/02 15:15:28 kaz Exp
 MenuUtil.h,v: Interface for MuTerminal menu items.

***************************************************************************/

#ifndef MENUUTIL_H_INCLUDED
#define MENUUTIL_H_INCLUDED

#include <SupportDefs.h>

#ifdef __cplusplus
extern "C" {
#endif

class BPopUpMenu;
class BMenu;
class PrefHandler;
  

  BPopUpMenu *	MakeFontMenu(ulong msg, const char *defaultFontName);
  BPopUpMenu *	MakeMenu(ulong msg, const char **items,
                const char *defaultItemName);
  
  int           longname2op(const char *longname);
  const char*   op2longname(int op);
  void          MakeEncodingMenu(BMenu *eMenu, int coding, bool flag);
  void          LoadLocaleFile (PrefHandler *);

#ifdef __cplusplus
}
#endif

#endif //MENUUTIL_H_INCLUDED
