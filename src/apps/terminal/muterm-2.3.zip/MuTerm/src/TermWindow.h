/*  Hey Emacs, this file is -*- c++ -*- ; 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.


 TermWindow.h,v 1.4 1999/03/22 02:38:21 kaz Exp
 TermWindow.h,v: Interface for MuTerminal Window class.

*/

#ifndef TERMWIN_H
#define TERMWIN_H

#include <Window.h>
#include <MessageRunner.h>

class BFont;
class TermView;
class TermParse;
class CodeConv;
class PrefDlg;
class FindDlg;

class TermWindow : public BWindow
{
public:
  TermWindow (BRect frame);
  ~TermWindow ();

  void		Quit (void);
  bool		QuitRequested (void);
  void		TermWinActivate (void);
  status_t	GetSupportedSuites (BMessage *msg);
  BHandler*	ResolveSpecifier (BMessage *msg, int32 index,
				  BMessage *specifier, int32 form,
				  const char *property);

private:
  void		InitWindow (void);
  void		SetupMenu (void);
  void		MessageReceived (BMessage *message);
  void		WindowActivated (bool);
  int		GetTimeZone (void);
  void		SetWindowTitle (void);
  void		MenusBeginning(void);
  void		doShowHelp (uint32 command);
  // Printing
  status_t	DoPageSetup (void);
  void		DoPrint (void);

  /*
   * data member
   */
  TermParse	*fTermParse;
  BMenuBar	*fMenubar;
  BMenu		*fFilemenu, *fEditmenu, *fEncodingmenu, *fHelpmenu;
  TermView	*fTermView;
  BView		*fBaseView;
  CodeConv	*fCodeConv;
  BMessage	*fPrintSettings;
  PrefDlg	*fPrefWindow;
  FindDlg	*fFindPanel;

  BMessageRunner *fWindowUpdate;

};

#endif // TERMWIN_H
