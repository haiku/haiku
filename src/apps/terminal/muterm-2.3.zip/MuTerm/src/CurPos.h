/* Hey Emacs, this file is -*- c++ -*-

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 CurPos.h,v 2.2 1999/10/02 15:14:40 kaz Exp
 CurPos.h,v: Interface for CurPos class.

***************************************************************************/

#ifndef	CURPOS_H_INCLUDED
#define	CURPOS_H_INCLUDED

#include <SupportDefs.h>

class CurPos
{
 public:
  int32 x;
  int32 y;

  CurPos();
  CurPos(int32 X, int32 Y);
  CurPos(const CurPos& cp);
  
  void		Set(int32 X, int32 Y);

  CurPos	&operator= (const CurPos &from);
  CurPos	operator+  (const CurPos&) const;
  CurPos	operator-  (const CurPos&) const;
  bool		operator!= (const CurPos&) const;
  bool		operator== (const CurPos&) const;
  bool		operator>  (const CurPos&) const;
  bool		operator>= (const CurPos&) const;
  bool		operator<  (const CurPos&) const;
  bool		operator<= (const CurPos&) const;

};

#endif /* CURPOS_H_INCLUDED */
