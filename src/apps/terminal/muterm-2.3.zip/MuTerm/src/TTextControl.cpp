/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 TTextControl.cpp,v 2.1 1999/10/02 15:18:21 kaz Exp
 TTextControl.cpp,v: Implementation for BTextControl sub class.

***************************************************************************/

#include <TextControl.h>
#include "TTextControl.h"

/************************************************************************
 *
 * CONSTRUCTOR and DESTRUCTOR
 *
 ***********************************************************************/

////////////////////////////////////////////////////////////////////////////
// TTextControl ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
TTextControl::TTextControl (BRect r, const char *name,
			    const char *label, const char *text,
			    BMessage *msg)
  :BTextControl (r, name, label, text, msg)
{
  mModified = false;
}

////////////////////////////////////////////////////////////////////////////
// ~TTextControl ()
//	Destructor.
////////////////////////////////////////////////////////////////////////////
TTextControl::~TTextControl ()
{
}

/*
 * PUBLIC MEMBER FUNCTIONS.
 */

////////////////////////////////////////////////////////////////////////////
// ModifiedText (int)
//	Dispatch modification message.
////////////////////////////////////////////////////////////////////////////
void
TTextControl::ModifiedText (int flag)
{
  mModified = flag;
  return;
}

////////////////////////////////////////////////////////////////////////////
// IsModified (void)
//	Dispatch modification message.
////////////////////////////////////////////////////////////////////////////
int
TTextControl::IsModified (void)
{
  return mModified;
}

