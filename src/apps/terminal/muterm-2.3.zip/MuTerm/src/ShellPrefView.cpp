/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 ShellPrefView.cpp,v 2.11 2000/02/07 01:52:52 kaz Exp
 ShellPrefView.cpp,v: Implementation for MuTerminal Shell Preference View.

***************************************************************************/

#include <View.h>
#include <Button.h>
#include <MenuField.h>
#include <Menu.h>
#include <MenuItem.h>
#include <PopUpMenu.h>
#include <TextControl.h>
#include <stdlib.h>
#include <Beep.h>

#include "ShellPrefView.h"
#include "PrefHandler.h"
#include "TermWindow.h"
#include "TermBuffer.h"
#include "TermConst.h"
#include "MenuUtil.h"
#include "TTextControl.h"

extern PrefHandler *gTermPref;

////////////////////////////////////////////////////////////////////////////
// AparancePrefView ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
ShellPrefView::ShellPrefView (BRect frame, const char *name,
			      TermWindow *window)
  :PrefView (frame, name)
{
  fTermWindow = window;

  //
  // Row and Cols
  //
  mCols = SetupTextControl(IERECT(0, 0, 160, 20), "", 120, MSG_COLS_CHANGED);
  mCols->SetText(gTermPref->getString(PREF_COLS));

  mRows = SetupTextControl(IERECT(0,30, 160, 20), "", 120, MSG_ROWS_CHANGED);
  mRows->SetText(gTermPref->getString(PREF_ROWS));

  //
  // Shell settings
  //
  mShell = SetupTextControl (IERECT (0, 60, 300, 20), "", 120, MSG_SHELL_CHANGED);
  mShell->SetText (gTermPref->getString (PREF_SHELL));

  mHistory = SetupTextControl (IERECT (0, 90, 180, 20), "", 120, MSG_HISTORY_CHANGED);
  mHistory->SetText (gTermPref->getString (PREF_HISTORY_SIZE));

}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
ShellPrefView::Revert (void)
{
  mCols->SetText (gTermPref->getString (PREF_COLS));
  mRows->SetText (gTermPref->getString (PREF_ROWS));
  mShell->SetText (gTermPref->getString (PREF_SHELL));
  mHistory->SetText (gTermPref->getString (PREF_HISTORY_SIZE));

}
////////////////////////////////////////////////////////////////////////////
// SaveIfModified (void)
//
////////////////////////////////////////////////////////////////////////////
void
ShellPrefView::SaveIfModified (void)
{
  BMessenger messenger (fTermWindow);

  if (mCols->IsModified()) {
    gTermPref->setString (PREF_COLS, mCols->Text());
    messenger.SendMessage (MSG_COLS_CHANGED);
    mCols->ModifiedText (false);
  }
  if (mRows->IsModified()) {
    gTermPref->setString (PREF_ROWS, mRows->Text());
    messenger.SendMessage (MSG_ROWS_CHANGED);
    mRows->ModifiedText (false);
  }
  if (mShell->IsModified())
    gTermPref->setString (PREF_SHELL, mShell->Text());

  if (mHistory->IsModified()) {
      int size;
      size = atoi(mHistory->Text());
      if (size < 512) mHistory->SetText("512");
      if (size > 1048575) mHistory->SetText("1048575");
      gTermPref->setString (PREF_HISTORY_SIZE, mHistory->Text());
  }

}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
ShellPrefView::SetControlLabels (PrefHandler &Labels)
{
  mCols->SetLabel(Labels.getString("Columns Label"));
  mRows->SetLabel(Labels.getString("Rows Label"));
  mShell->SetLabel(Labels.getString ("Shell Label"));
  mHistory->SetLabel(Labels.getString("History Size"));
}

/*
 *
 * PRIVATE MEMBER FUNCTIONS
 *
 */

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
ShellPrefView::AttachedToWindow (void)
{
  mCols->SetTarget (this);
  mRows->SetTarget (this);

  mShell->SetTarget (this);
  mHistory->SetTarget (this);
  
}

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
ShellPrefView::MessageReceived (BMessage *msg)
{
  bool modified = false;
  int size;

  switch (msg->what) {

    case MSG_COLS_CHANGED:
      size = atoi (mCols->Text());
      if (size >= MAX_COLS || size < MIN_COLS) {
	mCols->SetText (gTermPref->getString (PREF_COLS));
	beep ();
      } else {
	gTermPref->setString (PREF_COLS, mCols->Text());
	modified = true;
      }
      
      break;

  case MSG_ROWS_CHANGED:
    size = atoi (mRows->Text());
    if (size >= MAX_COLS || size < MIN_COLS) {
	mRows->SetText (gTermPref->getString (PREF_ROWS));
	beep ();
      } else {
	gTermPref->setString (PREF_ROWS, mRows->Text());
	modified = true;
      }
      
    break;

  case MSG_SHELL_CHANGED:
    gTermPref->setString (PREF_SHELL, mShell->Text());
    (this->Window())->PostMessage(MSG_PREF_MODIFIED);
    break;

  case MSG_HISTORY_CHANGED:
    size = atoi(mHistory->Text());
    
    if (size < 512 || size > 1048575) {
      mHistory->SetText(gTermPref->getString (PREF_HISTORY_SIZE));
      beep ();
    } else {
      gTermPref->setString (PREF_HISTORY_SIZE, mHistory->Text());
      (this->Window())->PostMessage(MSG_PREF_MODIFIED);
    }
    
    break;

  default:
    PrefView::MessageReceived(msg);
    break;      
  }
  
  if(modified){
   fTermWindow->PostMessage (msg);
   (this->Window())->PostMessage(MSG_PREF_MODIFIED);
  }
}
