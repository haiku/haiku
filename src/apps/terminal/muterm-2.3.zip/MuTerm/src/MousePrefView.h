/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 MousePrefView.h,v 2.7 1999/10/17 04:43:15 kaz Exp
 MousePrefView.h,v: Interface for MuTerminal Mouse Preference View.

***************************************************************************/

#ifndef MousePrefView__H_INCLUDED
#define MousePrefView__H_INCLUDED

#include "PrefView.h"

class TermWindow;

class MousePrefView : public PrefView
{
 public:
                MousePrefView (BRect r, const char *name, TermWindow *window);

  void          Revert (void);
  void          SetControlLabels (PrefHandler &Labels);

  void          AttachedToWindow (void);
  void          MessageReceived (BMessage *);
  
 private:

  BMenuField    *mSelect;
  BMenuField    *mSubMenu;
  BMenuField    *mPaste;
  BMenuField    *mMouseImage;
  BCheckBox	*mDragnCopy;

  TermWindow    *fTermWindow;

};

#endif //ShellPrefView_H_INCLUDED
