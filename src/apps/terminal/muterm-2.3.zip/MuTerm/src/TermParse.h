/*  Hey Emacs, this file is -*- c++ -*- ; 

	Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 TermParse.h,v 2.6 1999/10/13 15:16:40 kaz Exp
 TermParse.h,v: Interface for Escape Sequence parse class.

*/

#ifndef TERMPARSE_H
#define TERMPARSE_H

#include <kernel/OS.h>
#include <MessageRunner.h>
#include "TermConst.h"

class TermView;
class CodeConv;
class TermWindow;
 
//PtyReader buffer size.
#define READ_BUF_SIZE 2048

class TermParse : public BHandler
{
public:
  TermParse (void);
  ~TermParse (void);

  // Initialize TermParse and PtyReader thread.
  status_t InitTermParse (TermView *inViewObj, CodeConv *inConvObj);
  thread_id InitPtyReader (TermWindow *inWinObj);

  // Delete TermParse and PtyReader thread.
  status_t AbortTermParse (void);
  status_t AbortPtyReader (void);
  
  
private:
  //
  // Hook Functions.
  //


  // Escape Sequance parse thread.
  static int32 EscParse (void *);

  // Pty device reader thread.
  static int32 PtyReader (void *);

  // Reading ReadBuf at one Char.
  uchar GetReaderBuf (void);
  
  TermView *fViewObj;
  TermWindow *fWinObj;
  CodeConv *fConvObj;
  
  thread_id fParseThread;
  sem_id fParseSem;

  thread_id fReaderThread;
  sem_id fReaderSem;
  sem_id fReaderLocker;

  BMessageRunner *fCursorUpdate;

  uint fParser_p;	/* EscParse reading buffer pointer */
  int fLockFlag;	/* PtyReader lock flag */

  bool fQuitting;
  
  uchar fReadBuf[READ_BUF_SIZE]; /* Reading buffer */
  
};

#endif // TERMPARSE_H
