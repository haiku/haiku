/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 LangPrefView.cpp,v 2.12 1999/11/19 20:55:09 kaz Exp
 LangPrefView.cpp,v: Implementation for MuTerminal Language Preference View.

***************************************************************************/

#include <View.h>
#include <Button.h>
#include <MenuField.h>
#include <Menu.h>
#include <MenuItem.h>
#include <PopUpMenu.h>
#include <TextControl.h>
#include <CheckBox.h>
#include <Directory.h>
#include <Entry.h>

#include <string.h>

#include "LangPrefView.h"
#include "PrefHandler.h"
#include "TermConst.h"
#include "TermWindow.h"
#include "MenuUtil.h"

////////////////////////////////////////////////////////////////////////////
// LangPrefView ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
LangPrefView::LangPrefView (BRect frame, const char *name, TermWindow *window)
  :PrefView (frame, name)
{
  fTermWindow = window;
  
  //
  // Encoding.
  //
  int i = longname2op(gTermPref->getString (PREF_TEXT_ENCODING));
  BPopUpMenu *eMenu = new BPopUpMenu("");
  
  MakeEncodingMenu(eMenu, i, false);

  mCharCode = SetupMenuField(IERECT(0, 0, 300, 30) ,"", eMenu, false);

  //
  // GUI Language.
  //
  BPopUpMenu *menu = new BPopUpMenu("");
  char buf[256];
  BDirectory dir("/boot/home/config/settings/MuTerminal/menu/"); 
  BEntry ent; 
  BDirectory isDir;
  
  dir.Rewind(); 

  while (dir.GetNextEntry(&ent) == B_OK){
    // is this directory ?
    if(isDir.SetTo(&ent) == B_OK) continue;
    // not directory, let's add it to menu.
    ent.GetName(buf);
    BMenuItem *item = new BMenuItem(buf, new BMessage(MSG_LANG_CHANGED));
    if(!strcmp(buf, gTermPref->getString(PREF_GUI_LANGUAGE))){
      item->SetMarked(true);
    }
    menu->AddItem(item);
  }

  mCharCode->SetDivider (160);
  
  mLanguage = SetupMenuField (IERECT(0, 30, 300, 30), "" ,menu, false);
  mLanguage->SetDivider (160);

  //
  // Input Method Aware.
  //
  mInputMethod = SetupCheckBox(IERECT(0, 60, 200, 20), "", MSG_INPUT_METHOD_CHANGED);

  mInputMethod->SetValue (gTermPref->getInt32 (PREF_IM_AWARE));

}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
LangPrefView::Revert (void)
{
  mCharCode->Menu()->
   FindItem (gTermPref->getString(PREF_TEXT_ENCODING))->SetMarked(true);
  mLanguage->Menu()->
   FindItem (gTermPref->getString(PREF_GUI_LANGUAGE))->SetMarked(true);

}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
LangPrefView::SetControlLabels (PrefHandler &Labels)
{
  mCharCode->SetLabel(Labels.getString("Code Label"));
  mLanguage->SetLabel(Labels.getString("Language Label"));
  mInputMethod->SetLabel(Labels.getString("IMAware Label"));
}

/*
 *
 * PRIVATE MEMBER FUNCTIONS
 *
 */

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
LangPrefView::AttachedToWindow (void)
{
  mInputMethod->SetTarget (this);
  mCharCode->Menu()->SetTargetForItems(this);
  mLanguage->Menu()->SetTargetForItems(this);
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
LangPrefView::MessageReceived (BMessage *msg)
{
  switch (msg->what) {

  case MENU_ENCODING:
    gTermPref->setString (PREF_TEXT_ENCODING,
                          mCharCode->Menu()->FindMarked()->Label());
    break;
  
  case MSG_LANG_CHANGED:
    gTermPref->setString (PREF_GUI_LANGUAGE,
                          mLanguage->Menu()->FindMarked()->Label());
   fTermWindow->PostMessage (msg);
   (this->Window())->PostMessage(MSG_LANG_CHANGED);
    break;

  case MSG_INPUT_METHOD_CHANGED:
    gTermPref->setInt32 (PREF_IM_AWARE, mInputMethod->Value());
   fTermWindow->PostMessage (msg);
   (this->Window())->PostMessage(MSG_PREF_MODIFIED);
    break;

  default:
    PrefView::MessageReceived(msg);
    break;  
  }
}
