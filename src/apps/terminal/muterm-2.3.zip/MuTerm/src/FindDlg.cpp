/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 FindDlg.cpp,v 1.1 1999/12/05 16:13:36 kaz Exp
 FindDlg.cpp,v

***************************************************************************/

#include <Window.h>
#include <Rect.h>
#include <TextControl.h>
#include <Button.h>
#include <Message.h>
#include <stdio.h>
#include <File.h>
#include <String.h>

#include "FindDlg.h"
#include "TermApp.h"
#include "MenuUtil.h"
#include "PrefHandler.h"

// message define

const uint32 FPANEL_HIDE = 'Fhid';

//////////////////////////////////////////////////////////////////////////////
// FindDlg
// 	Constructer
//////////////////////////////////////////////////////////////////////////////
FindDlg::FindDlg (BRect frame, TermWindow *win)
  : BWindow(frame, "Find",
	    B_FLOATING_WINDOW, B_NOT_RESIZABLE|B_NOT_ZOOMABLE)
{
  PrefHandler title;
  LoadLocaleFile (&title);

  fWindow = win;
  this->SetTitle (title.getString ("Find"));

  AddShortcut ((ulong)'Q', (ulong)B_COMMAND_KEY, new BMessage (FPANEL_HIDE));
  AddShortcut ((ulong)'W', (ulong)B_COMMAND_KEY, new BMessage (FPANEL_HIDE));

  BRect r (10, 10, 120, 20);
  
  BTextControl *text_ctl = new BTextControl (r, "text", NULL, NULL, NULL);
  AddChild (text_ctl);

  r.Set (100, 40, 130, 60);
  BButton *button = new BButton (r, NULL, "Find", new BMessage (MSG_FIND_START));
  AddChild (button);
  
}

FindDlg::~FindDlg (void)
{
  
}

void
FindDlg::Quit (void)
{
  BWindow::Quit ();
}

