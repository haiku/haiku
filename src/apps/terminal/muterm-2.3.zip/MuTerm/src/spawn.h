/*  Hey Emacs, this file is -*- c++ -*- ; 

	Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 spawn.h,v 2.0 1999/10/02 15:08:58 kaz Exp
 spawn.h,v: define pty device, tty device control, and other.

*/

#ifndef SPAWN_H
#define SPAWN_H

/*
 * allow for mobility of the pty master/slave directories
 */

#define	PTYDEV		"/dev/pt/%c%c"
#define TTYDEV		"/dev/tt/%c%c"

#define PTYCHAR1	"pqrs"
#define	PTYCHAR2	"0123456789abcdef"

#define TTYFORMAT "/dev/tt/%d"
#define PTYFORMAT "/dev/pt/%d"

#define MAXPTTYS 16 * 4

#ifndef CEOF
#define CEOF ('D'&037)
#endif
#ifndef CSUSP
#define CSUSP ('@'&037)
#endif
#ifndef CQUIT
#define CQUIT ('\\'&037)
#endif
#ifndef CEOL
#define CEOL 0
#endif
#ifndef CSTOP
#define CSTOP ('Q'&037)
#endif
#ifndef CSTART
#define CSTART ('S'&037)
#endif
#ifndef CSWTCH
#define CSWTCH 0
#endif

/*
 * ANSI emulation.
 */
#define INQ	0x05
#define	FF	0x0C			/* C0, C1 control names		*/
#define	LS1	0x0E
#define	LS0	0x0F
#define	CAN	0x18
#define	SUB	0x1A
#define	ESC	0x1B
#define US	0x1F
#define	DEL	0x7F
#define HTS     ('H'+0x40)
#define	SS2	0x8E
#define	SS3	0x8F
#define	DCS	0x90
#define	OLDID	0x9A			/* ESC Z			*/
#define	CSI	0x9B
#define	ST	0x9C
#define	OSC	0x9D
#define	PM	0x9E
#define	APC	0x9F
#define	RDEL	0xFF

/*
 *  Prototype:
 */

int spawn_shell (int, int, const char *, const char *);
void Setenv (const char *, const char *);

extern pid_t sh_pid;	/* shell process ID */
extern char tty_name[];	/* tty device file name */
extern int pfd_num;	/* number of pfd */


#endif /* SPAWN_H */
