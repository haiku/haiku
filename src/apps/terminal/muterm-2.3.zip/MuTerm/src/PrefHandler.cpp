/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 PrefHandler.cpp,v 2.7 1999/10/02 15:17:10 kaz Exp
 PrefHandler.cpp,v: Imprementation for MuTerminal Preference handler.

***************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#include <GraphicsDefs.h>
#include <Message.h>
#include <File.h>
#include <Entry.h>
#include <NodeInfo.h>

#include "PrefHandler.h"

/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
PrefHandler::PrefHandler()
{
  mPrefContainer.what = 'Pref';
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
PrefHandler::PrefHandler(const PrefHandler* p)
{
  mPrefContainer = p->mPrefContainer;
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
PrefHandler::~PrefHandler()
{
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
status_t
PrefHandler::Open(const char *path, const prefDefaults *defaults)
{
  BEntry ent(path);
  if(ent.Exists()){
    return loadFromFile(&ent);
  }else{
    return loadFromDefault(defaults);
  }
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
status_t
PrefHandler::OpenText(const char *path,  const prefDefaults *defaults)
{
  BEntry ent(path);
  if(ent.Exists()){
    return loadFromTextFile(path);
  }else{
    return loadFromDefault(defaults);
  }
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
status_t
PrefHandler::Save(const char *path)
{
  status_t sts;
  BFile file(path, B_WRITE_ONLY | B_CREATE_FILE | B_ERASE_FILE);
  sts = mPrefContainer.Flatten(&file);
  return sts;
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
void
PrefHandler::SaveAsText(const char *path, const char *mimetype,
			const char *signature)
{
  BFile file(path, B_WRITE_ONLY | B_CREATE_FILE | B_ERASE_FILE);
  type_code type;
  char *key;
  char buf[256];
  
  for (int32 i = 0; mPrefContainer.GetInfo(B_STRING_TYPE, i, &key, &type) == B_OK; i++){  
    int len = sprintf(buf, "\"%s\" , \"%s\"\n", key, this->getString(key));
    file.Write(buf, len);
  }
  
  if(mimetype != NULL){
    BNodeInfo info(&file);
    info.SetType(mimetype);
    info.SetPreferredApp (signature);
  }  
  
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
int32 
PrefHandler::getInt32(const char *key)
{
  return atoi(mPrefContainer.FindString(key));
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
float 
PrefHandler::getFloat(const char *key)
{
  return atof(mPrefContainer.FindString(key));
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
const char* 
PrefHandler::getString(const char *key)
{
  const char *buf;

  buf = mPrefContainer.FindString(key);
  if (buf == NULL)
    buf = "Error!";

  return buf;
  
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////
bool
PrefHandler::getBool(const char *key)
{
  const char *s = mPrefContainer.FindString(key);
  if (!strcmp(s, PREF_TRUE)) return true;
  return false;
}
/////////////////////////////////////////////////////////////////////////////
// getRGB
// Returns RGB data from given key. 
/////////////////////////////////////////////////////////////////////////////
rgb_color
PrefHandler::getRGB(const char *key)
{
  int r, g, b;
  rgb_color col;
  const char *s = mPrefContainer.FindString(key);
  sscanf(s, "%d, %d, %d", &r, &g, &b);
  col.red = r;
  col.green = g;
  col.blue = b;
  col.alpha = 0;
  return col;
}
/////////////////////////////////////////////////////////////////////////////
// setInt32
// Setting Int32 data with key.
/////////////////////////////////////////////////////////////////////////////
void
PrefHandler::setInt32(const char *key, int32 data)
{
  char buf[20];
  sprintf(buf, "%d", (int)data);
  this->setString(key, buf);
}
/////////////////////////////////////////////////////////////////////////////
// setFloat
// Setting Float data with key
/////////////////////////////////////////////////////////////////////////////
void
PrefHandler::setFloat(const char *key, float data)
{
  char buf[20];
  sprintf(buf, "%g", data);
  this->setString(key, buf);
}
/////////////////////////////////////////////////////////////////////////////
// setBool
// Setting Bool data with key
/////////////////////////////////////////////////////////////////////////////
void
PrefHandler::setBool(const char *key, bool data)
{
  if(data){
    this->setString(key, PREF_TRUE);
  }else{
    this->setString(key, PREF_FALSE);
  }
}
/////////////////////////////////////////////////////////////////////////////
// this->setString
// Setting CString data with key
/////////////////////////////////////////////////////////////////////////////
void
PrefHandler::setString(const char *key, const char *data)
{
  mPrefContainer.RemoveName(key);
  mPrefContainer.AddString(key, data);
}
/////////////////////////////////////////////////////////////////////////////
// setRGB
// Setting RGB data with key
/////////////////////////////////////////////////////////////////////////////
void
PrefHandler::setRGB(const char *key, const rgb_color data)
{
  char buf[20];
  sprintf(buf, "%d, %d, %d", data.red, data.green, data.blue);
  this->setString(key, buf);
}
/////////////////////////////////////////////////////////////////////////////
// IsEmpty
// Check any peference stored or not.
/////////////////////////////////////////////////////////////////////////////
bool
PrefHandler::IsEmpty() const
{
  return mPrefContainer.IsEmpty();
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////

status_t
PrefHandler::loadFromFile(BEntry *ent)
{
  BFile file (ent, B_READ_ONLY);
  mPrefContainer.MakeEmpty();
  return mPrefContainer.Unflatten(&file);
}
/////////////////////////////////////////////////////////////////////////////
//
//
/////////////////////////////////////////////////////////////////////////////

status_t
PrefHandler::loadFromDefault(const prefDefaults* defaluts)
{
  if(defaluts == NULL) return B_ERROR;
  
  while(defaluts->key){
    this->setString(defaluts->key, defaluts->item);  
    ++defaluts;
  }
  return B_OK;
}
/////////////////////////////////////////////////////////////////////////////
//
// Text is "key","Content"
// Comment : Start with '#'
/////////////////////////////////////////////////////////////////////////////

status_t
PrefHandler::loadFromTextFile(const char * path)
{
char buf[1024];
char key[B_FIELD_NAME_LENGTH], data[512];
int n;
FILE *fp;

fp = fopen(path, "r");

  while(fgets(buf, sizeof(buf), fp) != NULL){
    if (*buf == '#') continue;
      n = sscanf(buf, "%*[\"]%[^\"]%*[\"]%*[^\"]%*[\"]%[^\"]", key, data);
      if (n == 2) this->setString(key, data);
  }

  fclose(fp);

  return B_OK;
}
