/* Hey Emacs, this file is -*- c++ -*- -*- coding:utf-8-unix -*-

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 TermIM.cpp,v 2.21 2000/04/01 17:13:29 kaz Exp
 TermIM.cpp,v: Implimentation for Japanese Input Method (TermView function).

***************************************************************************/
#include <stdio.h>
#include <Message.h>
#include <unistd.h>
#include <Input.h>
#include <Window.h>
#include <UTF8.h>
#include <TextControl.h>
#include <support/String.h>
#include "CodeConv.h"
#include "TermView.h"
#include "PrefHandler.h"
#include "spawn.h"

// defined TermApp.cpp
extern int pfd;	/* pesudo tty fd */
extern int gNowCoding;
extern PrefHandler *gTermPref;

////////////////////////////////////////////////////////////////////////////
// DoIMStart (Bmessage* msg)
//	Inline convert started.
////////////////////////////////////////////////////////////////////////////
void
TermView::DoIMStart (BMessage* msg)
{
  status_t sts;
 
  sts = msg->FindMessenger ("be:reply_to", &fIMMessenger);
  
  if(sts == B_OK){
    this ->GetCurPos (&fIMStartPos);
    fIMEndPos = fIMStartPos; 
    fIMflag = true;
    // Cursor off
    this->SetCurDraw (CUROFF);
  }
}
////////////////////////////////////////////////////////////////////////////
// DoIMStop (BMessage *)
//	Input method is over.
////////////////////////////////////////////////////////////////////////////
void
TermView::DoIMStop (BMessage* /*msg*/)
{
  this ->GetCurPos(&fIMStartPos);
#if 0
  if (gNowCoding == M_ISO_2022_JP && fImCodeState != 0) {
    char *end_of_jis = "(B";
    write (pfd, end_of_jis, 3);
    fImCodeState = 0;
    
  }
#endif
  fIMEndPos = fIMStartPos;
  fIMflag = false;
  //Cursor on
  //  this->SetCurDraw (CURON);
}
////////////////////////////////////////////////////////////////////////////
// DoIMChange (BMessage *)
//	receive B_INPUT_METHOD_CHANGE.
////////////////////////////////////////////////////////////////////////////
void
TermView::DoIMChange (BMessage* msg)
{
  bool confirmed;
  const char *str;
  status_t sts;
  CurPos inPos;
    
  if (!fIMflag) return;

  sts = msg->FindString("be:string", &str);
  if(sts != B_OK) return;
  
  fIMString.SetTo(str);

  this->SetCurDraw (CUROFF);
  msg->FindBool("be:confirmed", &confirmed);

  if(confirmed){
    ConfirmString (str, fIMString.Length());
    /*
     * snooze write function complete.
     */
    snooze (100 * 1000);
    return;
  }

  /*
   * Input Japanese string.
   */
  const rgb_color savecolor = HighColor();
  char buf[5];
  int32 sel_start, sel_end;
  msg->FindInt32("be:selection", 0, &sel_start);
  msg->FindInt32("be:selection", 1, &sel_end);
      
  int str_p = 0;
  int x = fIMStartPos.x, y = fIMStartPos.y;
  int width = 0, n = 0;
  int x1, x2, y1, y2;
   
  BFont saveFont;
  GetFont(&saveFont);
  SetFont(&fFullFont);

  this->LockLooper();
  for(;;){
    for(;;){
      if (!*str) goto end;

      n = GetCharFromUTF8String(str, buf);
      width = fCodeConv->UTF8GetFontWidth((uchar *)&buf);

      if (x >= fTermColumns - 1)
	break;

      x1 = x * fFontWidth;
      x2 = x1 + fFontWidth * width;
      y1 = y * fFontHeight + fTop;
      y2 = y1 + fFontHeight;
    
      if((sel_start != sel_end)
         && (str_p >= sel_start && str_p < sel_end)){
        SetHighColor (gTermPref->getRGB (PREF_IM_SELECT_COLOR));
        SetLowColor (gTermPref->getRGB (PREF_IM_SELECT_COLOR));
      }else{
        SetHighColor (gTermPref->getRGB (PREF_IM_BACK_COLOR));
        SetLowColor (gTermPref->getRGB (PREF_IM_BACK_COLOR));
      }
      FillRect (BRect (x1, y1, x2 - 1, y2 - 1));

      SetHighColor (gTermPref->getRGB (PREF_IM_FORE_COLOR));
      MovePenTo (x1, y1 + fFontAscent);
      DrawString (buf);
 
      str_p += n;
      str += n;
      
      x += width;
    }
    x = 0;
    y++;
    
   ////////////////////////////////////////////////////
   // mosi pos.y ga gamen yori ookikunattara Scroll saseru.
   ////////////////////////////////////////////////////
  }
end:
  if (y == fIMEndPos.y && x < fIMEndPos.x) {
    inPos.Set (x, y);
    this->TermDrawRegion (inPos, fIMEndPos);
  } else if (y < fIMEndPos.y) {
    inPos.Set (x, y);
    this->TermDrawRegion (inPos, fIMEndPos);
  }
    
  fIMEndPos.Set (x, y);

  Window()->Flush();
  this->UnlockLooper();
  SetFont(&saveFont);
  SetHighColor (savecolor);
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
TermView::DoIMLocation (BMessage* /*msg*/)
{
  BMessage reply(B_INPUT_METHOD_EVENT);
  reply.AddInt32("be:opcode", B_INPUT_METHOD_LOCATION_REQUEST);

  BPoint  screenDelta = ConvertToScreen(B_ORIGIN);
  screenDelta -= B_ORIGIN;
  
  int32 x = fIMStartPos.x;
  int32 y = fIMStartPos.y;
  const char *s = fIMString.String();
  char buf[5];
  int32 str_p = 0;
  int width;

  for(;;){
    for(;;){
      if (!*s) goto end;

      int32 n = GetCharFromUTF8String(s, buf);
      width = fCodeConv->UTF8GetFontWidth((uchar *)&buf);

      BPoint p(x * fFontWidth, y * fFontHeight + fTop);
      p += screenDelta;
	
      reply.AddPoint("be:location_reply", p);
      reply.AddFloat("be:height_reply", fFontHeight);

      s += n;
      str_p += n;
       
      x += width;
      if (x >= fTermColumns - 1)
	break;
   }   
   x = 0;
   y ++;
  }

end:
  fIMMessenger.SendMessage(&reply);
}
////////////////////////////////////////////////////////////////////////////
// void SetIMAware (bool)
// 	Set Input Method Aware
////////////////////////////////////////////////////////////////////////////
void
TermView::SetIMAware (bool flag)
{
  if (flag) {
    this->SetFlags (Flags() | B_INPUT_METHOD_AWARE);
  } else {
    this->SetFlags (Flags() & ~B_INPUT_METHOD_AWARE);
  }
}

////////////////////////////////////////////////////////////////////////////
// CountUTF8Char (const char *, char *)
//	Count UTF8 multibyte character.
////////////////////////////////////////////////////////////////////////////
#undef BEGINS_CHAR
#define BEGINS_CHAR(byte) ((byte & 0xc0) != 0x80)

int32
TermView::GetCharFromUTF8String (const char *str, char *outbuf)
{
  int32 n = 0;
  int32 len = 1;  
  outbuf[n] = *str++;

  while(*str){
    if(BEGINS_CHAR(*str)) break;
    n++;
    outbuf[n] = *str++;
    len++;
  }

  outbuf[n + 1 ] = 0;

  return len;
}

////////////////////////////////////////////////////////////////////////////
// GetWIdthFromUTF8String (const char *)
//	Calc UTF8 String width
////////////////////////////////////////////////////////////////////////////
int32
TermView::GetWidthFromUTF8String (const char *str)
{
  int32 n = 0;
  uchar buf[4];
  int width = 0;

  while (*str) {
    buf[n++] = *str++;
    do {
      if (BEGINS_CHAR(*str)) break;
      buf[n++] = *str++;
    } while (1);

    buf[n] = '\0';
    width += fCodeConv->UTF8GetFontWidth (buf);
    n = 0;
  }

  return width;
}

////////////////////////////////////////////////////////////////////////////
// IMConfirm (void)
//	confirm IM string
////////////////////////////////////////////////////////////////////////////

void
TermView::DoIMConfirm (void)
{
  BMessage reply (B_INPUT_METHOD_EVENT);

  if (fIMflag) {
    this->TermDrawRegion (fIMStartPos, fIMEndPos);

    ConfirmString (fIMString.String(), fIMString.Length());

    reply.AddInt32 ("be:opcode", B_INPUT_METHOD_STOPPED);
    fIMMessenger.SendMessage (&reply);
    fIMflag = false;
  }

}

////////////////////////////////////////////////////////////////////////////
// ConfirmString (const char *, int32)
//	confirm IM string
////////////////////////////////////////////////////////////////////////////
void
TermView::ConfirmString (const char *str, int32 num_bytes)
{

  long state = 0;
  
  /* IM confirmed(Kakutei) process. */
  this->TermDrawRegion (fIMStartPos, fIMEndPos);

  if (gNowCoding != M_UTF8) {
    //    int32 state = 0;
    int32 d_len = num_bytes * 256;
    
    uchar *dstbuf = new uchar [d_len];

    int coding = coding_translation_table [gNowCoding];
    
    convert_from_utf8 (coding, (char *)str,
		       &num_bytes, (char *)dstbuf,
		       &d_len, &state, '?');

    write (pfd, dstbuf, d_len);
    delete dstbuf;
#if 1
    if (gNowCoding == M_ISO_2022_JP && state != 0) {
      char *end_of_jis = "(B";
      write (pfd, end_of_jis, 3);
    }
#endif
  }
  else {
    write (pfd, str, num_bytes);
  }
}
