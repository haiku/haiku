/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 PrefDlg.h,v 2.7 1999/10/17 04:43:15 kaz Exp
 PrefDlg.h,v: Interface for MuTerminal Preference Dialog.

***************************************************************************/
#ifndef PREFDLG_H_INCLUDED
#define PREFDLG_H_INCLUDED

#include <Window.h>
#include "PrefHandler.h"

// local message, so these are in .cpp files....
const ulong MSG_SAVE_PRESSED = 'okok';
const ulong MSG_SAVEAS_PRESSED = 'canl';
const ulong MSG_REVERT_PRESSED = 'revt';
const ulong MSG_PREF_CLOSED = 'mspc';


// Notify PrefDlg closed to TermWindow

class BRect;
class BMessage;
class BTextControl;
class TermWindow;
class PrefView;
class BButton;
class PrefHandler;
class BFilePanel;

class PrefDlg : public BWindow
{
public:
  PrefDlg(TermWindow *inWindow);
  ~PrefDlg ();
  
  void          Quit();

private:
  void		doSave (void);
  void		doSaveAs (void);
  void		doRevert (void);
  void          LanguageChanged (void);
  void          SaveRequested(BMessage *msg);
  
  bool          QuitRequested ();
  void          MessageReceived (BMessage *msg);

  void          SetupContent();

  BBox*         SetupBox(BRect r, const char *label, BView *parent);
  BButton*      SetupButton(BRect r, const char *label, ulong msg,
			    BView *parent, bool defaultButton=false);

  static BRect	CenteredRect(BRect r);

private:
  TermWindow    *fTermWindow;
  BTabView      *fTabView;
  PrefHandler   *fPrefTemp;
  BFilePanel    *fSavePanel;
  BButton       *fSaveAsFileButton;
  BButton       *fRevertButton;
  BButton       *fSaveButton;
  
  bool          fDirty;
};

#endif //PREFDLG_H_INCLUDED
