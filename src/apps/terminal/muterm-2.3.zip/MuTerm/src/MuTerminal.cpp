/* Hey Emacs, this file is -*- c++ -*- ; 

	Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.


 MuTerminal.cpp,v 2.6 1999/10/02 15:16:18 kaz Exp
 MuTerminal.cpp,v: main routine for MuTerminal.

**************************************************************************/

#include <stdio.h>

#include "TermApp.h"
#include "PrefHandler.h"

/* global varriables */
int pfd;	/* pesudo tty fd */
int pfd_no;	/* pfd number */

PrefHandler *gTermPref;		/* Preference temporary */

////////////////////////////////////////////////////////////////////////////
// main (int argc, char **argv)
//	main routine of MuTerminal.
////////////////////////////////////////////////////////////////////////////
int
main ()
{
  TermApp app;
  app.Run ();

  return 0;
}
