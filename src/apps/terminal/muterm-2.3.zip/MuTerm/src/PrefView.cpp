/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 PrefView.cpp,v 2.7 1999/11/19 20:55:09 kaz Exp
 PrefView.cpp,v: Implementation for MuTerminal Preference Dialog.

***************************************************************************/

#include <Box.h>
#include <Button.h>
#include <RadioButton.h>
#include <ColorControl.h>
#include <StringView.h>
#include <TextControl.h>
#include <CheckBox.h>
#include <MenuField.h>
#include <Message.h>
#include <String.h>
#include <Window.h>

#include "PrefHandler.h"
#include "TermConst.h"
#include "PrefView.h"
#include "TTextControl.h"

/************************************************************************
 *
 * PUBLIC MEMBER FUNCTIONS.
 *
 ***********************************************************************/

////////////////////////////////////////////////////////////////////////////
// PrefView ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
PrefView::PrefView (BRect frame, const char *name)
  :BView (frame, name, B_FOLLOW_ALL_SIDES, B_WILL_DRAW)
{
  SetViewColor(ui_color(B_PANEL_BACKGROUND_COLOR));
  fLabel.SetTo(name);
}

////////////////////////////////////////////////////////////////////////////
// ~PrefView ()
//	Destructor.
////////////////////////////////////////////////////////////////////////////
PrefView::~PrefView()
{

}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
const char *
PrefView::ViewLabel (void) const
{
  return fLabel.String();
}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
PrefView::Revert (void)
{
}
////////////////////////////////////////////////////////////////////////////
// CanApply()
// Determines whether view can respont Apply command or not.
////////////////////////////////////////////////////////////////////////////
bool
PrefView::CanApply ()
{
  return true;
}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
PrefView::SaveIfModified (void)
{
}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
PrefView::SetControlLabels (PrefHandler &/*labelPref*/)
{
}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
PrefView::MessageReceived (BMessage *msg)
{
  TTextControl *textctl;

  switch (msg->what) {
  case MSG_TEXT_MODIFIED:
    if (msg->FindPointer ("source", (void**)&textctl) == B_OK) {
      textctl->ModifiedText (true);
    }
    break;

  default:
    BView::MessageReceived (msg);
  }
  
}


//////////////////////////////////////////////////////////////////////////////
// SetupBox
// make Box
//////////////////////////////////////////////////////////////////////////////
BBox *
PrefView::SetupBox(BRect r, const char *label)
{
  BBox *b;

  b = new BBox(r);
  b->SetLabel(label);
  AddChild(b);
  return b;
}
//////////////////////////////////////////////////////////////////////////////
// SetupButton
// make Button
//////////////////////////////////////////////////////////////////////////////
BButton *
PrefView::SetupButton(BRect r, const char *label, ulong msg, bool defaultButton)
{
  BButton *b;

  b = new BButton(r, "", label, new BMessage(msg));
  AddChild(b);
  
  if (defaultButton)
    (Window())->SetDefaultButton(b);

  return b;
}
//////////////////////////////////////////////////////////////////////////////
// SetupRadio
// make Radio Button
//////////////////////////////////////////////////////////////////////////////
BRadioButton *
PrefView::SetupRadio(BRect r, const char *label, ulong msg)
{
  BRadioButton *rb;

  rb = new BRadioButton(r, "", label, new BMessage(msg));
  AddChild(rb);
  return rb;
}
//////////////////////////////////////////////////////////////////////////////
// SetupTextControl
// make Label
//////////////////////////////////////////////////////////////////////////////
TTextControl *
PrefView::SetupTextControl(BRect r, const char *label, float div, ulong msg)
{
  TTextControl *tc;

  tc = new TTextControl(r, "", label, "", new BMessage(msg));
  tc->SetDivider(div);
  tc->SetModificationMessage ( new BMessage(MSG_TEXT_MODIFIED));
  AddChild(tc);
  return tc;
}

//////////////////////////////////////////////////////////////////////////////
// SetupTextLabel
// make Text Label
//////////////////////////////////////////////////////////////////////////////
BStringView *
PrefView::SetupTextLabel(BRect r, const char *label)
{
  BStringView *sv;

  sv = new BStringView(r, "", label);
  AddChild(sv);
  return sv;
}



//////////////////////////////////////////////////////////////////////////////
// SetupCheckBox
// Make Check Box.
//////////////////////////////////////////////////////////////////////////////
BCheckBox *
PrefView::SetupCheckBox(BRect r, const char *label, ulong msg)
{
  BCheckBox *cb;

  cb = new BCheckBox(r, "", label, new BMessage(msg));
  AddChild(cb);
  return cb;
}
//////////////////////////////////////////////////////////////////////////////
// SetupMenuField
// Make BMenuField.
//////////////////////////////////////////////////////////////////////////////
BMenuField *
PrefView::SetupMenuField(BRect r, const char *label,
			 BMenu *menu, bool flag)
{
  BMenuField *mf;

  mf = new BMenuField(r, "", label, menu);
  if (flag)
    mf->SetDivider (0);
  AddChild(mf);
  return mf;
}

//////////////////////////////////////////////////////////////////////////////
// SetupBColorControl
// Make BColorControl.
//////////////////////////////////////////////////////////////////////////////
BColorControl *
PrefView::SetupBColorControl(BPoint p, color_control_layout layout, float cell_size, ulong msg)
{
  BColorControl *col;
  
  col = new BColorControl( p, layout, cell_size, "", new BMessage(msg));
  AddChild(col);
  return col;
}

