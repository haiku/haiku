/* Hey Emacs, this file is -*- c++ -*-

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 AppearPrefView.cpp,v 2.15 2000/02/07 01:52:51 kaz Exp
 AppearPrefView.cpp,v: Implementation for MuTerminal Appearance Preference View.

***************************************************************************/

#include <View.h>
#include <Button.h>
#include <MenuField.h>
#include <Menu.h>
#include <MenuItem.h>
#include <PopUpMenu.h>
#include <TextControl.h>
#include <Beep.h>

#include <stdlib.h>

#include "AppearPrefView.h"
#include "PrefHandler.h"
#include "TermWindow.h"
#include "TermConst.h"
#include "MenuUtil.h"
#include "TTextControl.h"

#define MAX_FONT_SIZE 32
#define MIN_FONT_SIZE 6

////////////////////////////////////////////////////////////////////////////
// AppearPrefView ()
//	Constructor.
////////////////////////////////////////////////////////////////////////////
AppearancePrefView::AppearancePrefView (BRect frame, const char *name,
					TermWindow *window)
  :PrefView (frame, name)
{
  const char *color_tbl[]=
  {
    PREF_TEXT_FORE_COLOR,
    PREF_TEXT_BACK_COLOR,
    PREF_CURSOR_FORE_COLOR,
    PREF_CURSOR_BACK_COLOR,
    PREF_SELECT_FORE_COLOR,
    PREF_SELECT_BACK_COLOR,
    PREF_IM_FORE_COLOR,
    PREF_IM_BACK_COLOR,
    PREF_IM_SELECT_COLOR,
    NULL
  };

  fTermWindow = window;
  //
  // Half and Full Font.
  //
  mHalfFont =
    SetupMenuField(IERECT(0, 0, 220, 20), 
                   "",
                   MakeFontMenu(MSG_HALF_FONT_CHANGED,
                   gTermPref->getString(PREF_HALF_FONT_FAMILY)),
                   false);

  mHalfFont->SetDivider (120);

  mHalfSize = SetupTextControl(IERECT(220, 0, 80, 20),
	                           "",
                               50,
                               MSG_HALF_SIZE_CHANGED);
  mHalfSize->SetText(gTermPref->getString(PREF_HALF_FONT_SIZE));

  mHalfSize->SetDivider (50);

  mFullFont =
    SetupMenuField(IERECT(0, 30, 220, 20),
                   "",
                   MakeFontMenu(MSG_FULL_FONT_CHANGED,
                   gTermPref->getString(PREF_FULL_FONT_FAMILY)),
                   false);

  mFullFont->SetDivider (120);
  
  mFullSize = SetupTextControl(IERECT(220, 30, 80, 20),
                               "",
                               50,
                               MSG_FULL_SIZE_CHANGED);
  mFullSize->SetText(gTermPref->getString(PREF_FULL_FONT_SIZE));

  mFullSize->SetDivider (50);

  //
  // Color Control
  //
  mColorField = SetupMenuField (IERECT(0, 60, 200, 20),
				"",
				MakeMenu (MSG_COLOR_FIELD_CHANGED,
				          color_tbl,
				          color_tbl[0]),
				true);

  mColorCtl = SetupBColorControl(BPoint(20, 85),
				  B_CELLS_32x8,
				  6,
				  MSG_COLOR_CHANGED);
  
  mColorCtl->SetValue(gTermPref->getRGB(PREF_TEXT_FORE_COLOR));

}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
AppearancePrefView::Revert (void)
{

  mHalfSize->SetText (gTermPref->getString (PREF_HALF_FONT_SIZE));
  mFullSize->SetText (gTermPref->getString (PREF_FULL_FONT_SIZE));
  mColorField->Menu()->ItemAt(0)->SetMarked (true);
  mColorCtl->SetValue (gTermPref->getRGB(PREF_TEXT_FORE_COLOR));

  mHalfFont->Menu()->
    FindItem (gTermPref->getString(PREF_HALF_FONT_FAMILY))->SetMarked(true);
  mFullFont->Menu()->
    FindItem (gTermPref->getString(PREF_FULL_FONT_FAMILY))->SetMarked(true);

  return;
  
}

////////////////////////////////////////////////////////////////////////////
// SaveIfModified (void)
//
////////////////////////////////////////////////////////////////////////////
void
AppearancePrefView::SaveIfModified (void)
{
  BMessenger messenger (fTermWindow);
  
  if (mHalfSize->IsModified()) {
    gTermPref->setString (PREF_HALF_FONT_SIZE, mHalfSize->Text());
    messenger.SendMessage (MSG_HALF_SIZE_CHANGED);
    mHalfSize->ModifiedText (false);
  }
  if (mFullSize->IsModified()) {
    gTermPref->setString (PREF_FULL_FONT_SIZE, mFullSize->Text());
    messenger.SendMessage (MSG_FULL_SIZE_CHANGED);
    mFullSize->ModifiedText (false);
  }
  return;
}
//////////////////////////////////////////////////////////////////////////////
//
//
//////////////////////////////////////////////////////////////////////////////
void
AppearancePrefView::SetControlLabels (PrefHandler &Labels)
{
  mHalfFont->SetLabel(Labels.getString("HalfFont Label"));
  mHalfSize ->SetLabel(Labels.getString("HalfSize Label"));
  mFullFont->SetLabel(Labels.getString("FullFont Label"));
  mFullSize->SetLabel(Labels.getString("FullSize Label"));
}

////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
AppearancePrefView::AttachedToWindow (void)
{
  mHalfSize->SetTarget (this);
  mFullSize->SetTarget (this);
  mHalfFont->Menu()->SetTargetForItems(this);
  mFullFont->Menu()->SetTargetForItems(this);  

  mColorCtl->SetTarget (this);
  mColorField->Menu()->SetTargetForItems(this);

}
////////////////////////////////////////////////////////////////////////////
//
//
////////////////////////////////////////////////////////////////////////////
void
AppearancePrefView::MessageReceived (BMessage *msg)
{
  bool modified = false;
  int size;
  
  switch (msg->what) {  
  case MSG_HALF_FONT_CHANGED:
    gTermPref->setString (PREF_HALF_FONT_FAMILY,
			  mHalfFont->Menu()->FindMarked()->Label());
    modified = true;
    break;
      
  case MSG_HALF_SIZE_CHANGED:
    size = atoi (mHalfSize->Text());
    if (size > MAX_FONT_SIZE || size < MIN_FONT_SIZE) {
      mHalfSize->SetText (gTermPref->getString (PREF_HALF_FONT_SIZE));
      beep ();
    }
    else {
      gTermPref->setString (PREF_HALF_FONT_SIZE,
			    mHalfSize->Text());
      modified = true;
    }
    
    break;
      
  case MSG_FULL_FONT_CHANGED:
    gTermPref->setString (PREF_FULL_FONT_FAMILY,
			  mFullFont->Menu()->FindMarked()->Label());
    modified = true;
    break;
      
  case MSG_FULL_SIZE_CHANGED:
    size = atoi (mHalfSize->Text());
    if (size > MAX_FONT_SIZE || size < MIN_FONT_SIZE) {
      mFullSize->SetText (gTermPref->getString (PREF_FULL_FONT_SIZE));
      beep ();
    }
    else {
      gTermPref->setString (PREF_FULL_FONT_SIZE, mFullSize->Text());
    }
    
    modified = true;
    break;
      
  case MSG_COLOR_CHANGED:
    gTermPref->setRGB(mColorField->Menu()->FindMarked()->Label(),
		      mColorCtl->ValueAsColor());
    modified = true;
    break;

  case MSG_COLOR_FIELD_CHANGED:
    mColorCtl->SetValue
      (gTermPref->getRGB (mColorField->Menu()->FindMarked()->Label()));
    break;
  
  default:
    PrefView::MessageReceived(msg);
    return; // Oh !      
  }

  if(modified){
   fTermWindow->PostMessage (msg);
   (this->Window())->PostMessage(MSG_PREF_MODIFIED);
  }
}
