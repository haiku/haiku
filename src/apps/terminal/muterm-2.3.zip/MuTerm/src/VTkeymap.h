#define CASE_IGNORE 0
#define CASE_FUNCTION 1
#define CASE_UP_ARROW 2
#define CASE_DOWN_ARROW 3
#define CASE_RIGHT_ARROW 4
#define CASE_LEFT_ARROW 5
#define CASE_RET_ENTR 6

#define F1_KEY 0x02
#define F2_KEY 0x03
#define F3_KEY 0x04
#define F4_KEY 0x05
#define F5_KEY 0x06
#define F6_KEY 0x07
#define F7_KEY 0x08
#define F8_KEY 0x09
#define F9_KEY 0x0a
#define F10_KEY 0x0b
#define F11_KEY 0x0c
#define F12_KEY 0x0d

#define RETURN_KEY 0x47
#define ENTER_KEY 0x5b

#define LEFT_ARROW_KEY 0x61
#define RIGHT_ARROW_KEY 0x63
#define UP_ARROW_KEY 0x57
#define DOWN_ARROW_KEY 0x62

#define HOME_KEY 0x20
#define INSERT_KEY 0x1f
#define END_KEY 0x35
#define PAGE_UP_KEY 0x21
#define PAGE_DOWN_KEY 0x36



#define LEFT_ARROW_KEY_CODE "[D"
#define RIGHT_ARROW_KEY_CODE "[C"
#define UP_ARROW_KEY_CODE "[A"
#define DOWN_ARROW_KEY_CODE "[B"

#define HOME_KEY_CODE "[@"
#define INSERT_KEY_CODE "[2~"
#define END_KEY_CODE "[["
#define PAGE_UP_KEY_CODE "[5~"
#define PAGE_DOWN_KEY_CODE "[6~"

//#define IS_DOWN_KEY(x) (info.key_states[(x) / 8] & key_state_table[(x) % 8])
#define IS_DOWN_KEY(x) \
(info.key_states[(x) >> 3] & (1 << (7 - ((x) % 8))))
