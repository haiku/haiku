/* Hey Emacs, this file is -*- c++ -*-
   
    Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 TermApp.h,v 2.6 2000/02/07 01:54:15 kaz Exp
 TermApp.h,v: Interface for MuTerminal Application class.
  
*************************************************************************/

#ifndef TERMAPP_H
#define TERMAPP_H

#include <app/Application.h>
#include <String.h>

extern int pfd;
extern char *ptyname;

class TermWindow;
class TermParse;
class BRect;
class AboutDlg;

class TermApp : public BApplication
{
public:
               TermApp (void);
               ~TermApp (void);

private:
  /*
   * Hook functions
   */
  void          ReadyToRun (void);
  void          Quit (void);
  void          MessageReceived (BMessage* msg);
  void          AboutRequested (void);
  void          RefsReceived(BMessage *message);
  void          ArgvReceived(int32 argc, char **argv);

  /*
   * Public Member functions.
   */
  void          MakeTermWindow (BRect &frame);
  void          RunNewTerm (void);
  void          SwitchTerm(void);
  void          ActivateTermWindow(team_id id);
  void          ShowHTML(BMessage *msg);

  void          Usage(char *name);
  
private:
  bool          IsMinimize (team_id);

  int		fRows, fCols, fXpos, fYpos;
  rgb_color	fFg, fBg, fCurFg, fCurBg, fSelFg, fSelbg;
  rgb_color	fImfg, fImbg, fImSel;
  
  TermWindow    *fTermWindow;
  TermParse     *fTermParse;
  BRect         fTermFrame;
  AboutDlg	*fAboutPanel;

  BString	CommandLine;
  
};

#endif

