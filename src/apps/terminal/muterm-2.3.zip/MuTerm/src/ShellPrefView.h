/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 ShellPrefView.h,v 2.5 1999/10/02 15:18:11 kaz Exp
 ShellPrefView.h,v: Interface for MuTerminal Shell Preference View.

***************************************************************************/

#ifndef ShellPrefView__H_INCLUDED
#define ShellPrefView__H_INCLUDED

#include "PrefView.h"

class TermWindow;
class TTextControl;

class ShellPrefView : public PrefView
{
 public:
                ShellPrefView (BRect r, const char *name, TermWindow *window);

  virtual void  SaveIfModified (void);

  void          Revert (void);
  void          SetControlLabels (PrefHandler &Labels);

  void          AttachedToWindow (void);
  void          MessageReceived (BMessage *);

 private:
  TTextControl  *mCols;
  TTextControl  *mRows;

  TTextControl  *mShell;
  TTextControl  *mHistory;

  TermWindow 	*fTermWindow;
  
};

#endif //ShellPrefView_H_INCLUDED
