/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 AboutDlg.h,v 1.3 1999/12/05 10:40:31 kaz Exp
 AboutDlg.h,v: Interface for MuTerminal About Dialog.

***************************************************************************/
#ifndef ABOUTDLG_H_INCLUDED
#define ABOUTDLG_H_INCLUDED

#include <Window.h>
#include <TextView.h>

const ulong MSG_ABOUT_CLOSED = 'msac';

class BRect;
class BBitmap;
class BMessage;
class TermApp;

class AboutDlg : public BWindow
{
public:
  AboutDlg(BRect frame, TermApp *app);
  ~AboutDlg ();

 private:
  virtual void	Quit (void);
  
  BBitmap	*background;
  TermApp	*fApp;

};

class AboutView : public BView
{
 public:
  AboutView (BRect);
  ~AboutView ();

 private:
  virtual void	Draw (BRect updateRect);
  virtual void	AttachedToWindow ();
  virtual void	MouseDown (BPoint where);
  virtual void	Pulse ();

  bool		staffroll;
  int		count;
  BRect		scrrect;
  BBitmap	*background;
  BBitmap	*offscreen;
  BBitmap	*textbitmap;
  int32		last_point;

};

#endif /* ABOUTDLG_H_INCLUDED */
