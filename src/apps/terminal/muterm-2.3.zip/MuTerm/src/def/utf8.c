#include <stdio.h>

main()
{
  int i,j,k;
  char c;
  FILE *fp;
  
  fp = fopen("utf8.txt","w");
    
  for (i=0x20; i<=0x7F; i++) {
    //    if ((i % 32) == 0) fprintf (fp,"\n");
    c = i;
    fprintf(fp,"%c",c);
  }

  for (i=0x80; i<=0x7ff; i++){
    //    if ((i % 32) == 0) fprintf (fp,"\n");
    j = i;
    j = j >> 6;
    c = 0xc0;
    c = c | j;
    fprintf(fp,"%c",c);
    j = i;
    j = j & 0x3f;
    c = 0x80;
    c =c | j;
    fprintf(fp,"%c",c);
  }

  for (i=0x800; i<=0xffff; i++){
    //    if ((i % 32) == 0) fprintf (fp,"\n");
    j = i;
    j = j >> 12;
    c = 0xe0;
    c = c | j;
    fprintf(fp,"%c",c);
    j = i;
    j = j >> 6;
    j = j & 0x3f;
    c = 0x80;
    c =c | j;
    fprintf(fp,"%c",c);
    j = i;
    j = j & 0x3f;
    c = 0x80;
    c =c | j;
    fprintf(fp,"%c",c);
  }
   
  close (fp);
}
