/*  Hey Emacs, this file is -*- c++ -*-

	Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 CodeConv.h,v 2.4 1999/10/17 04:43:15 kaz Exp
 CodeConv.h,v: Interface for MuTerminal Code Conversion class.

****************************************************************************/

#ifndef CODECONV_H
#define CODECONV_H

#include <SupportDefs.h>
#include "Coding.h"

#define BEGINS_CHAR(byte) ((byte & 0xc0) >= 0x80)

/*
 *  Coding system define.
 */
class CodeConv
{
  /*
   * Constructor and Destuructor.
   */
public:
  CodeConv (void);
  ~CodeConv (void);
  
  /*
   * Public member functions.
   */
  int	UTF8GetFontWidth (const uchar *string);

  /* internal(UTF8) -> coding */
  int	ConvertFromInternal (const uchar *src, uchar *dst, int coding);

  /* coding -> internal(UTF8) */
  void	ConvertToInternal   (const uchar *src, uchar *dst, int coding);
  
  /*
   *	PRIVATE MEMBER.
   */

private:		
  /*
   * Private member functions.
   */

  void	euc_to_sjis (uchar *buf);

  unsigned short UTF8toUnicode (const uchar *utf8);

  /*
   * DATA Member.
   */
  
  int	fNowCoding;
  
};

#endif /* CODECONV_H */
