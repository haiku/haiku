/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 AppearPrefView.h,v 2.6 1999/10/17 04:43:15 kaz Exp
 AppearPrefView.h,v: Interaface for MuTerminal Apperarance Preference View.

***************************************************************************/

#ifndef AppearancePrefView_H_INCLUDED
#define ApperaancePrefView_H_INCLUDED

#include "PrefView.h"

class TermWindow;
class TTextControl;

class AppearancePrefView : public PrefView
{
 public:
                AppearancePrefView(BRect r,
				   const char *name,
				   TermWindow *window);

  virtual void  Revert (void);
  virtual void  SaveIfModified (void);
  void          SetControlLabels (PrefHandler &Labels);

  virtual void  MessageReceived (BMessage *);
  virtual void  AttachedToWindow (void);

 private:
  TTextControl  *mHalfSize;
  TTextControl  *mFullSize;
  BMenuField    *mHalfFont;
  BMenuField    *mFullFont;

  BMenuField    *mColorField;
  BColorControl *mColorCtl;
  
  int           mSubMenu_button;
  int           mPaste_button;
  
  TermWindow    *fTermWindow;
  
};

#endif //AppearancePrefView_H_INCLUDED
