/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 PrefView.h,v 2.8 1999/10/02 15:17:30 kaz Exp
 PrefView.h,v: Interface for Preference Tab Container View.

***************************************************************************/

#ifndef PREFVIEW_H_INCLUDED
#define PREFVIEW_H_INCLUDED
#include <View.h>
#include <ColorControl.h>
#include <String.h>

// Interface Element's Coordinate System to BRect.
#define IERECT(X,Y,W,H)  BRect((X),(Y),(X+W-1),(Y+H-1))

class PrefHandler;
class BRect;
class BBox;
class TTextControl;
class BStringView;
class BRadioButton;
class BButton;
class BCheckBox;
class BMenuField;

enum {
  PREF_APP_VIEW,
  PREF_SHELL_VIEW,
  PREF_LANG_VIEW
};

//
// Appearance Message
//
const ulong MSG_HALF_FONT_CHANGED	= 'mchf';
const ulong MSG_HALF_SIZE_CHANGED	= 'mchs';
const ulong MSG_FULL_FONT_CHANGED	= 'mcff';
const ulong MSG_FULL_SIZE_CHANGED	= 'mcfs';
const ulong MSG_COLOR_FIELD_CHANGED	= 'mccf';
const ulong MSG_COLOR_CHANGED		= 'mcbc';
const ulong MSG_SELECT_CHANGED		= 'mcss';
const ulong MSG_SUBMENU_CHANGED		= 'mcsm';
const ulong MSG_PASTE_CHANGED		= 'mcpm';
const ulong MSG_MIMAGE_CHANGED		= 'mimg';
const ulong MSG_DRAGN_COPY_CHANGED	= 'mdgn';

//
// ShellMessage
//
const ulong MSG_COLS_CHANGED		= 'mccl';
const ulong MSG_ROWS_CHANGED		= 'mcrw';
const ulong MSG_SHELL_CHANGED		= 'mshl';
const ulong MSG_HISTORY_CHANGED		= 'mhst';

const ulong MSG_LANG_CHANGED		= 'mclg';
const ulong MSG_INPUT_METHOD_CHANGED	= 'mcim';

//
// TextControl Modification Message.
//
const ulong MSG_TEXT_MODIFIED		= 'tcmm';
const ulong MSG_PREF_MODIFIED		= 'mpmo';


extern PrefHandler *gTermPref;

class PrefView : public BView
{
public:

                PrefView (BRect frame, const char *name);
  virtual       ~PrefView();
  const char *  ViewLabel (void) const;
  virtual void	Revert (void);
  virtual bool  CanApply ();
  virtual void	MessageReceived (BMessage *msg);
  virtual void	SaveIfModified (void);
  virtual void	SetControlLabels (PrefHandler &labelPref);

  BBox*         SetupBox	(BRect r, const char *label);

  BRadioButton* SetupRadio	(BRect r, const char *label, ulong msg);

  TTextControl* SetupTextControl(BRect r, const char *label,
				 float div, ulong msg);

  BStringView*  SetupTextLabel	(BRect r, const char *label);

  BButton*      SetupButton	(BRect r, const char *label,
				 ulong msg, bool defaultButton=false);

  BCheckBox*    SetupCheckBox	(BRect r, const char *label, ulong msg);

  BMenuField*   SetupMenuField	(BRect r, const char *label,
				 BMenu *menu, bool flag);

  BColorControl* SetupBColorControl	(BPoint p,
					 color_control_layout layout,
					 float cell_size, ulong msg);

  private:
  
  BString fLabel;

};

#endif //PREFVIEW_H_INCLUDED
