/* Hey Emacs, this file is -*- c++ -*- 

  Multilingual Terminal Emulator "MuTerminal".
 
 Copyright (C) 1998,99 Kazuho Okui and Takashi Murai. ALL RIGHT RESERVED
  
 This file is part of MuTerminal.

 MuTerminal is free software; you can redistribute it and/or modify
 it under the terms of the GNU General Public License as published by
 the Free Software Foundation; either version 2, or (at your option)
 any later version.

 FindDlg.h,v 1.1 1999/12/05 16:13:36 kaz Exp
 FindDlg.h,v: Interface for MuTerminal About Dialog.

***************************************************************************/
#ifndef FINDDLG_H_INCLUDED
#define FINDDLG_H_INCLUDED

#include <Window.h>
#include <TextView.h>

#include "CurPos.h"

const ulong MSG_FIND_START = 'msac';

class BRect;
class BBitmap;
class BMessage;
class TermWindow;

class FindDlg : public BWindow
{
public:
  FindDlg(BRect frame, TermWindow *win);
  ~FindDlg ();

  void		Find (CurPos *start, CurPos *end);

 private:
  virtual void	Quit (void);
  
  BString	*fFindString;
  TermWindow	*fWindow;

};


#endif /* FINDDLG_H_INCLUDED */
